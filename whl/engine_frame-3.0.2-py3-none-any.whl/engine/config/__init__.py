
def get_cfg():
    from engine.config.defaults import _C
    return _C.clone()
